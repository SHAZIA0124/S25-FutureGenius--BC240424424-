<?php
session_start();
include('config.php');

// Access Control: Ensure session exists and user is an Admin
if (!isset($_SESSION["id"]) || ($_SESSION["usertype"] ?? '') !== "admin") {
    header("location: ../admin_login.php");
    exit;
}

// ------------------------------------------------------------------
// 1. KPI Aggregations
// ------------------------------------------------------------------

// Total Users Breakdown by Role
$total_users_res = mysqli_query($conn, "
    SELECT 
        COUNT(*) AS total_users,
        SUM(CASE WHEN role = 'student' THEN 1 ELSE 0 END) AS total_students,
        SUM(CASE WHEN role = 'instructor' THEN 1 ELSE 0 END) AS total_instructors,
        SUM(CASE WHEN role = 'expert' THEN 1 ELSE 0 END) AS total_experts
    FROM users
");
$users_data = mysqli_fetch_assoc($total_users_res);
$total_students = $users_data['total_students'] ?? 0;
$total_instructors = $users_data['total_instructors'] ?? 0;
$total_experts = $users_data['total_experts'] ?? 0;

// Total Questions & Answers
$total_questions_res = mysqli_query($conn, "SELECT COUNT(*) AS total FROM questions");
$total_questions = mysqli_fetch_assoc($total_questions_res)['total'] ?? 0;

$total_answers_res = mysqli_query($conn, "SELECT COUNT(*) AS total FROM answers");
$total_answers = mysqli_fetch_assoc($total_answers_res)['total'] ?? 0;

// Active Job Opportunities Listed
$total_jobs_res = mysqli_query($conn, "SELECT COUNT(*) AS total FROM jobs WHERE is_active = 1");
$total_jobs = mysqli_fetch_assoc($total_jobs_res)['total'] ?? 0;

// Top Category by Discussion Activity (Most Questions)
$top_cat_res = mysqli_query($conn, "
    SELECT c.name, COUNT(q.id) AS question_count 
    FROM questions q 
    JOIN categories c ON q.category_id = c.id 
    GROUP BY q.category_id 
    ORDER BY question_count DESC 
    LIMIT 1
");
$top_cat_data = mysqli_fetch_assoc($top_cat_res);
$most_frequent_category = $top_cat_data['name'] ?? 'N/A';
$most_frequent_cat_count = $top_cat_data['question_count'] ?? 0;

// Most Active Contributor (User with Most Answers)
$top_user_res = mysqli_query($conn, "
    SELECT u.full_name, COUNT(a.id) AS total_answers
    FROM answers a
    JOIN users u ON a.user_id = u.id
    GROUP BY a.user_id
    ORDER BY total_answers DESC
    LIMIT 1
");
$top_user_data = mysqli_fetch_assoc($top_user_res);
$top_user_name = $top_user_data['full_name'] ?? 'N/A';
$top_user_answers = $top_user_data['total_answers'] ?? 0;

// ------------------------------------------------------------------
// 2. Chart Data Queries
// ------------------------------------------------------------------

// Chart 1: Questions by Category
$cat_chart_res = mysqli_query($conn, "
    SELECT c.name AS category_name, COUNT(q.id) as total 
    FROM categories c 
    LEFT JOIN questions q ON c.id = q.category_id 
    GROUP BY c.id
");
$cat_labels = [];
$cat_counts = [];
while ($row = mysqli_fetch_assoc($cat_chart_res)) {
    $cat_labels[] = $row['category_name'];
    $cat_counts[] = (int)$row['total'];
}

// Chart 2: Jobs by Type
$jobs_chart_res = mysqli_query($conn, "
    SELECT job_type, COUNT(*) as total 
    FROM jobs 
    WHERE is_active = 1
    GROUP BY job_type
");
$job_type_labels = [];
$job_type_counts = [];
while ($row = mysqli_fetch_assoc($jobs_chart_res)) {
    $job_type_labels[] = ucfirst($row['job_type']);
    $job_type_counts[] = (int)$row['total'];
}

// Chart 3: Most Answered Questions
$top_questions_res = mysqli_query($conn, "
    SELECT q.title, COUNT(a.id) as answer_count 
    FROM questions q 
    LEFT JOIN answers a ON q.id = a.question_id 
    GROUP BY q.id 
    ORDER BY answer_count DESC 
    LIMIT 5
");
$question_labels = [];
$question_counts = [];
while ($row = mysqli_fetch_assoc($top_questions_res)) {
    $question_labels[] = strlen($row['title']) > 20 ? substr($row['title'], 0, 20) . '...' : $row['title'];
    $question_counts[] = (int)$row['answer_count'];
}

// ------------------------------------------------------------------
// 3. Action Table: Recent Community Questions
// ------------------------------------------------------------------
$recent_questions_list = mysqli_query($conn, "
    SELECT q.*, 
           u.full_name AS author_name, 
           c.name AS category_name,
           (SELECT COUNT(*) FROM answers a WHERE a.question_id = q.id) AS answer_count
    FROM questions q 
    JOIN users u ON q.user_id = u.id 
    JOIN categories c ON q.category_id = c.id 
    ORDER BY q.created_at DESC 
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AQDesk</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">

    <style>
    .dashboard-card {
        border: none;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
        transition: all 0.3s ease;
    }

    .dashboard-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }

    .stat-number {
        font-size: 1.8rem;
        font-weight: 700;
        margin: 0;
    }

    .icon-circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
    }

    .table-card {
        border-radius: 12px;
        border: none;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }
    </style>
</head>

<body class="bg-light">

    <?php  include 'admin_navbar.php'; ?>
    <div class="container-fluid mt-4 px-4 mb-5">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="font-weight-bold text-dark">AQDesk Admin Dashboard</h2>
                <p class="text-muted mb-0">Overview of community Q&A, active opportunities, and user activity metrics.
                </p>
            </div>
            <div>
                <a href="" class="btn btn-outline-primary font-weight-bold mr-2">
                    <i class="fas fa-question-circle mr-1"></i> View Q&A Forum
                </a>
                <a href="" class="btn btn-primary font-weight-bold">
                    <i class="fas fa-briefcase mr-1"></i> Manage Jobs
                </a>
            </div>
        </div>

        <!-- Metric KPI Cards Row 1 -->
        <div class="row">

            <!-- Total Community Questions -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card dashboard-card bg-primary text-white h-100">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 small mb-1">Total Questions Asked</h6>
                                <p class="stat-number"><?php echo number_format($total_questions); ?></p>
                            </div>
                            <div class="icon-circle bg-white text-primary">
                                <i class="fas fa-comments"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- User Roles Breakdown -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card dashboard-card bg-info text-white h-100">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 small mb-1">Students / Instructors / Experts</h6>
                                <p class="stat-number" style="font-size: 1.3rem;">
                                    <?php echo number_format($total_students); ?> /
                                    <?php echo number_format($total_instructors); ?> /
                                    <?php echo number_format($total_experts); ?>
                                </p>
                            </div>
                            <div class="icon-circle bg-white text-info">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Total Answers Provided -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card dashboard-card bg-success text-white h-100">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-white-50 small mb-1">Total Answers Posted</h6>
                                <p class="stat-number"><?php echo number_format($total_answers); ?></p>
                            </div>
                            <div class="icon-circle bg-white text-success">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Active Job Listings -->
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card dashboard-card bg-warning text-dark h-100">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-dark small mb-1">Active Opportunities</h6>
                                <p class="stat-number"><?php echo number_format($total_jobs); ?></p>
                            </div>
                            <div class="icon-circle bg-white text-warning">
                                <i class="fas fa-briefcase"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Metric KPI Cards Row 2 -->
        <div class="row mb-2">
            <div class="col-md-6 mb-4">
                <div class="card dashboard-card border-left border-primary shadow-sm h-100"
                    style="border-left-width: 5px !important;">
                    <div class="card-body p-3 d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small font-weight-bold text-uppercase">Top Category by
                                Questions</span>
                            <h4 class="font-weight-bold text-primary mb-0 mt-1">
                                <?php echo htmlspecialchars($most_frequent_category); ?></h4>
                            <small class="text-muted"><?php echo $most_frequent_cat_count; ?> Questions Posted</small>
                        </div>
                        <div class="icon-circle bg-light text-primary">
                            <i class="fas fa-tags"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 mb-4">
                <div class="card dashboard-card border-left border-success shadow-sm h-100"
                    style="border-left-width: 5px !important;">
                    <div class="card-body p-3 d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small font-weight-bold text-uppercase">Top Contributor</span>
                            <h4 class="font-weight-bold text-success mb-0 mt-1">
                                <?php echo htmlspecialchars($top_user_name); ?></h4>
                            <small class="text-muted"><?php echo $top_user_answers; ?> Answers Contributed</small>
                        </div>
                        <div class="icon-circle bg-light text-success">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Analytical Charts Row -->
        <div class="row mb-4">

            <!-- Category Breakdown Chart -->
            <div class="col-lg-4 mb-4">
                <div class="card table-card h-100">
                    <div class="card-body">
                        <h6 class="card-title font-weight-bold text-secondary mb-3">
                            <i class="fas fa-layer-group text-primary mr-2"></i>Questions by Category
                        </h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Most Answered Questions Chart -->
            <div class="col-lg-4 mb-4">
                <div class="card table-card h-100">
                    <div class="card-body">
                        <h6 class="card-title font-weight-bold text-secondary mb-3">
                            <i class="fas fa-chart-bar text-success mr-2"></i>Most Answered Questions
                        </h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="questionsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Jobs Breakdown Doughnut Chart -->
            <div class="col-lg-4 mb-4">
                <div class="card table-card h-100">
                    <div class="card-body">
                        <h6 class="card-title font-weight-bold text-secondary mb-3">
                            <i class="fas fa-chart-pie text-warning mr-2"></i>Jobs by Opportunity Type
                        </h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="jobTypeChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Action Table: Recent Community Questions -->
        <div class="row">
            <div class="col-12">
                <div class="card table-card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="card-title font-weight-bold text-secondary mb-0">
                                <i class="fas fa-clock text-info mr-2"></i>Recent Community Questions
                            </h5>
                            <a href="" class="small font-weight-bold text-primary">View All Forum
                                &rarr;</a>
                        </div>

                        <?php if (mysqli_num_rows($recent_questions_list) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle small mb-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Title</th>
                                        <th>Category</th>
                                        <th>Author</th>
                                        <th>Answers</th>
                                        <th>Date Posted</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($q = mysqli_fetch_assoc($recent_questions_list)): ?>
                                    <tr>
                                        <td>#<?php echo $q['id']; ?></td>
                                        <td><strong><?php echo htmlspecialchars($q['title']); ?></strong></td>
                                        <td><span
                                                class="badge badge-info"><?php echo htmlspecialchars($q['category_name']); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($q['author_name']); ?></td>
                                        <td><span
                                                class="badge badge-light border"><?php echo $q['answer_count']; ?></span>
                                        </td>
                                        <td><?php echo date('d M Y, h:i A', strtotime($q['created_at'])); ?></td>
                                        <td>
                                            <a href="" class="btn btn-sm btn-primary">View
                                                Discussion</a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div class="text-center text-muted py-4">No recent questions found.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
    // 1. Questions by Category Bar Chart
    const catLabels = <?php echo json_encode($cat_labels); ?>;
    const catCounts = <?php echo json_encode($cat_counts); ?>;
    new Chart(document.getElementById('categoryChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: catLabels.length > 0 ? catLabels : ['No Data'],
            datasets: [{
                label: 'Questions',
                data: catCounts.length > 0 ? catCounts : [0],
                backgroundColor: '#007bff',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // 2. Most Answered Questions Horizontal Bar Chart
    const questionLabels = <?php echo json_encode($question_labels); ?>;
    const questionCounts = <?php echo json_encode($question_counts); ?>;
    new Chart(document.getElementById('questionsChart').getContext('2d'), {
        type: 'bar',
        data: {
            labels: questionLabels.length > 0 ? questionLabels : ['No Data'],
            datasets: [{
                label: 'Answers',
                data: questionCounts.length > 0 ? questionCounts : [0],
                backgroundColor: '#28a745',
                borderRadius: 4
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });

    // 3. Jobs by Opportunity Type Doughnut Chart
    const jobTypeLabels = <?php echo json_encode($job_type_labels); ?>;
    const jobTypeCounts = <?php echo json_encode($job_type_counts); ?>;
    new Chart(document.getElementById('jobTypeChart').getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: jobTypeLabels.length > 0 ? jobTypeLabels : ['No Data'],
            datasets: [{
                data: jobTypeCounts.length > 0 ? jobTypeCounts : [1],
                backgroundColor: ['#ffc107', '#17a2b8', '#007bff', '#28a745', '#dc3545']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    </script>
</body>

</html>
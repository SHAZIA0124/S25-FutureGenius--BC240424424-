<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$job_type = isset($_GET['job_type']) ? trim($_GET['job_type']) : '';

$sql = "SELECT j.*, u.full_name 
        FROM jobs j 
        JOIN users u ON j.posted_by = u.id 
        WHERE j.is_active = 1";

$params = [];
$types = "";

if (!empty($search)) {
    $sql .= " AND (j.title LIKE ? OR j.company_name LIKE ? OR j.location LIKE ?)";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

if (!empty($job_type)) {
    $sql .= " AND j.job_type = ?";
    $params[] = $job_type;
    $types .= "s";
}

$sql .= " ORDER BY j.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Opportunities - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php   include('navbar.php'); ?>

    <div class="container my-5">
        <h2 class="mb-4">Explore Career & Learning Opportunities</h2>

        <!-- Search & Filter Card -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <form method="GET" action="student_jobs.php">
                    <div class="row">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <label class="font-weight-bold">Search Keywords</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                </div>
                                <input type="text" name="search" class="form-control"
                                    placeholder="Search title, company, location..."
                                    value="<?= htmlspecialchars($search) ?>">
                            </div>
                        </div>

                        <div class="col-md-4 mb-3 mb-md-0">
                            <label class="font-weight-bold">Opportunity Type</label>
                            <select name="job_type" class="form-control">
                                <option value="">All Types</option>
                                <option value="full-time" <?= $job_type === 'full-time' ? 'selected' : '' ?>>Full-Time
                                </option>
                                <option value="part-time" <?= $job_type === 'part-time' ? 'selected' : '' ?>>Part-Time
                                </option>
                                <option value="internship" <?= $job_type === 'internship' ? 'selected' : '' ?>>
                                    Internship</option>
                                <option value="contract" <?= $job_type === 'contract' ? 'selected' : '' ?>>Contract
                                </option>
                                <option value="remote" <?= $job_type === 'remote' ? 'selected' : '' ?>>Remote</option>
                            </select>
                        </div>

                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">Filter</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Job Cards List -->
        <div class="row">
            <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($job = mysqli_fetch_assoc($result)): ?>
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h5 class="card-title text-primary font-weight-bold mb-0">
                                    <?= htmlspecialchars($job['title']) ?></h5>
                                <span
                                    class="badge badge-info text-uppercase px-2 py-1"><?= htmlspecialchars($job['job_type']) ?></span>
                            </div>

                            <h6 class="text-muted mb-3"><i class="fas fa-building mr-1"></i>
                                <?= htmlspecialchars($job['company_name'] ?? 'N/A') ?></h6>

                            <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt mr-1"></i>
                                <?= htmlspecialchars($job['location'] ?? 'Not specified') ?></p>
                            <p class="text-muted small mb-3"><i class="fas fa-money-bill-wave mr-1"></i>
                                <?= htmlspecialchars($job['salary_range'] ?? 'Negotiable') ?></p>

                            <p class="card-text text-secondary">
                                <?= htmlspecialchars(substr($job['description'], 0, 120)) ?>...</p>
                        </div>

                        <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                            <small class="text-muted"><i class="far fa-clock mr-1"></i> Deadline:
                                <?= $job['application_deadline'] ? date('d M Y', strtotime($job['application_deadline'])) : 'Open' ?></small>
                            <a href="job_detail.php?id=<?= $job['id'] ?>" class="btn btn-sm btn-outline-primary">View
                                Details <i class="fas fa-arrow-right ml-1"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <?php else: ?>
            <div class="col-md-12">
                <div class="alert alert-info text-center">No matching opportunities found.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

</body>

</html>
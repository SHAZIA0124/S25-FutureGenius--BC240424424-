<?php
session_start();
include('config.php');

// Access Control: Ensure session exists and user is an Admin
if (!isset($_SESSION["id"]) || ($_SESSION["usertype"] ?? '') !== "admin") {
    header("location: ../admin_login.php");
    exit;
}


// ------------------------------------------------------------------
// 1. AJAX Backend Endpoint for Modal Data Fetching
// ------------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'get_user_details' && isset($_GET['user_id'])) {
    header('Content-Type: application/json');
    $user_id = intval($_GET['user_id']);

    // Fetch main user details
    $u_stmt = $conn->prepare("SELECT id, full_name, email, role, phone, bio, education, skills, location, address, status, created_at FROM users WHERE id = ?");
    $u_stmt->bind_param("i", $user_id);
    $u_stmt->execute();
    $user = $u_stmt->get_result()->fetch_assoc();

    if (!$user) {
        echo json_encode(['error' => 'User not found']);
        exit;
    }

    $response = ['user' => $user];

    // Fetch Questions asked by user
    $q_stmt = $conn->prepare("
        SELECT q.*, c.name AS category_name 
        FROM questions q 
        JOIN categories c ON q.category_id = c.id 
        WHERE q.user_id = ? 
        ORDER BY q.created_at DESC 
        LIMIT 5
    ");
    $q_stmt->bind_param("i", $user_id);
    $q_stmt->execute();
    $response['questions'] = $q_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Fetch Answers posted by user
    $a_stmt = $conn->prepare("
        SELECT a.*, q.title AS question_title 
        FROM answers a 
        JOIN questions q ON a.question_id = q.id 
        WHERE a.user_id = ? 
        ORDER BY a.created_at DESC 
        LIMIT 5
    ");
    $a_stmt->bind_param("i", $user_id);
    $a_stmt->execute();
    $response['answers'] = $a_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Fetch Posted Jobs (if instructor or expert)
    $j_stmt = $conn->prepare("
        SELECT * FROM jobs 
        WHERE posted_by = ? 
        ORDER BY created_at DESC 
        LIMIT 5
    ");
    $j_stmt->bind_param("i", $user_id);
    $j_stmt->execute();
    $response['jobs'] = $j_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    echo json_encode($response);
    exit;
}

// ------------------------------------------------------------------
// 2. Action Handlers (Toggle Status & Delete User)
// ------------------------------------------------------------------
$alert_message = "";
$alert_type = "success";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['toggle_status'])) {
        $target_id = intval($_POST['user_id']);
        $new_status = $_POST['new_status'] === 'deactive' ? 'deactive' : 'active';
        
        $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $target_id);
        if ($stmt->execute()) {
            $alert_message = "User status updated to '{$new_status}' successfully.";
        } else {
            $alert_message = "Failed to update user status.";
            $alert_type = "danger";
        }
    }

    if (isset($_POST['delete_user'])) {
        $target_id = intval($_POST['user_id']);
        
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $target_id);
        if ($stmt->execute()) {
            $alert_message = "User deleted successfully.";
        } else {
            $alert_message = "Failed to delete user.";
            $alert_type = "danger";
        }
    }
}

// ------------------------------------------------------------------
// 3. User Listing Queries & Filters
// ------------------------------------------------------------------
$role_filter = $_GET['role'] ?? 'All';
$status_filter = $_GET['status'] ?? 'All';
$search_query = trim($_GET['search'] ?? '');

$where_clauses = ["1=1"];
$params = [];
$param_types = "";

if ($role_filter !== 'All' && in_array(strtolower($role_filter), ['student', 'instructor', 'expert'])) {
    $where_clauses[] = "u.role = ?";
    $params[] = strtolower($role_filter);
    $param_types .= "s";
}

if ($status_filter !== 'All' && in_array(strtolower($status_filter), ['active', 'deactive'])) {
    $where_clauses[] = "u.status = ?";
    $params[] = strtolower($status_filter);
    $param_types .= "s";
}

if (!empty($search_query)) {
    $where_clauses[] = "(u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.location LIKE ?)";
    $like_search = "%" . $search_query . "%";
    array_push($params, $like_search, $like_search, $like_search, $like_search);
    $param_types .= "ssss";
}

$where_sql = implode(" AND ", $where_clauses);
$sql = "
    SELECT u.* 
    FROM users u 
    WHERE {$where_sql} 
    ORDER BY u.created_at DESC
";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($param_types, ...$params);
}
$stmt->execute();
$users_list = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - AQDesk Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">

    <style>
    .nav-tabs .nav-link {
        color: #495057 !important;
        font-weight: 600;
        border: 1px solid transparent;
        transition: all 0.2s ease-in-out;
    }

    .nav-tabs .nav-link:hover {
        color: #007bff !important;
        border-color: #e9ecef #e9ecef #dee2e6;
    }

    .nav-tabs .nav-link.active {
        color: #007bff !important;
        background-color: #fff !important;
        border-color: #dee2e6 #dee2e6 #fff !important;
        border-top: 3px solid #007bff !important;
        font-weight: bold;
    }

    .table-card {
        border-radius: 12px;
        border: none;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    }

    .badge-role-student {
        background-color: #17a2b8;
        color: #fff;
    }

    .badge-role-instructor {
        background-color: #28a745;
        color: #fff;
    }

    .badge-role-expert {
        background-color: #6f42c1;
        color: #fff;
    }

    .avatar-initial {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: #e9ecef;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: #495057;
    }
    </style>
</head>

<body class="bg-light">

    <?php include 'admin_navbar.php'; ?>

    <div class="container-fluid mt-4 px-4 mb-5">

        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="font-weight-bold text-dark">User Management</h2>
                <p class="text-muted mb-0">View user profiles, adjust account statuses, and inspect user activity.</p>
            </div>
            <div>
                <a href="dashboard.php" class="btn btn-outline-secondary font-weight-bold">
                    <i class="fas fa-arrow-left mr-1"></i> Back to Dashboard
                </a>
            </div>
        </div>

        <!-- Alert Notification -->
        <?php if (!empty($alert_message)): ?>
        <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($alert_message); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Search & Filter Card -->
        <div class="card table-card mb-4">
            <div class="card-body">
                <form method="GET" action="admin_manage_users.php" class="form-row align-items-end">

                    <div class="form-group col-md-4 mb-2">
                        <label class="small font-weight-bold text-muted">Search User</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                            </div>
                            <input type="text" name="search" class="form-control"
                                placeholder="Name, Email, Phone, or Location..."
                                value="<?php echo htmlspecialchars($search_query); ?>">
                        </div>
                    </div>

                    <div class="form-group col-md-3 mb-2">
                        <label class="small font-weight-bold text-muted">Filter Role</label>
                        <select name="role" class="form-control">
                            <option value="All" <?php echo $role_filter === 'All' ? 'selected' : ''; ?>>All Roles
                            </option>
                            <option value="student"
                                <?php echo strtolower($role_filter) === 'student' ? 'selected' : ''; ?>>Students
                            </option>
                            <option value="instructor"
                                <?php echo strtolower($role_filter) === 'instructor' ? 'selected' : ''; ?>>Instructors
                            </option>
                            <option value="expert"
                                <?php echo strtolower($role_filter) === 'expert' ? 'selected' : ''; ?>>Experts</option>
                        </select>
                    </div>

                    <div class="form-group col-md-3 mb-2">
                        <label class="small font-weight-bold text-muted">Filter Status</label>
                        <select name="status" class="form-control">
                            <option value="All" <?php echo $status_filter === 'All' ? 'selected' : ''; ?>>All Statuses
                            </option>
                            <option value="active"
                                <?php echo strtolower($status_filter) === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="deactive"
                                <?php echo strtolower($status_filter) === 'deactive' ? 'selected' : ''; ?>>Deactive
                            </option>
                        </select>
                    </div>

                    <div class="form-group col-md-2 mb-2 d-flex">
                        <button type="submit" class="btn btn-primary btn-block font-weight-bold mr-1">
                            Filter
                        </button>
                        <a href="admin_manage_users.php" class="btn btn-outline-secondary" title="Reset Filters">
                            <i class="fas fa-undo"></i>
                        </a>
                    </div>

                </form>
            </div>
        </div>

        <!-- Users Table -->
        <div class="card table-card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th class="pl-4">User</th>
                                <th>Role</th>
                                <th>Contact Info</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Joined Date</th>
                                <th class="text-center pr-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($users_list && $users_list->num_rows > 0): ?>
                            <?php while ($user = $users_list->fetch_assoc()): ?>
                            <tr>
                                <td class="pl-4">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-initial mr-3">
                                            <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <strong
                                                class="text-dark"><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                            <br>
                                            <small class="text-muted">ID: #<?php echo $user['id']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                        $role_class = 'badge-role-student';
                                        if ($user['role'] === 'instructor') $role_class = 'badge-role-instructor';
                                        if ($user['role'] === 'expert') $role_class = 'badge-role-expert';
                                    ?>
                                    <span class="badge <?php echo $role_class; ?> text-capitalize px-2 py-1">
                                        <?php echo htmlspecialchars($user['role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small class="d-block"><i
                                            class="fas fa-envelope text-muted mr-1"></i><?php echo htmlspecialchars($user['email']); ?></small>
                                    <small class="d-block"><i
                                            class="fas fa-phone text-muted mr-1"></i><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></small>
                                </td>
                                <td>
                                    <small
                                        class="font-weight-bold"><?php echo htmlspecialchars($user['location'] ?? 'N/A'); ?></small>
                                </td>
                                <td>
                                    <?php if (strtolower($user['status']) === 'active'): ?>
                                    <span class="badge badge-success px-2 py-1"><i
                                            class="fas fa-check-circle mr-1"></i>Active</span>
                                    <?php else: ?>
                                    <span class="badge badge-danger px-2 py-1"><i
                                            class="fas fa-ban mr-1"></i>Deactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small
                                        class="text-muted"><?php echo date('d M Y', strtotime($user['created_at'])); ?></small>
                                </td>
                                <td class="text-center pr-4">
                                    <div class="btn-group">
                                        <!-- View Details Button -->
                                        <button type="button" class="btn btn-sm btn-outline-info view-user-btn"
                                            data-id="<?php echo $user['id']; ?>" title="View Full Details">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <!-- Status Toggle Form -->
                                        <form method="POST" action="admin_manage_users.php" class="d-inline"
                                            onsubmit="return confirm('Change status for this user?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="new_status"
                                                value="<?php echo strtolower($user['status']) === 'active' ? 'deactive' : 'active'; ?>">
                                            <button type="submit" name="toggle_status"
                                                class="btn btn-sm <?php echo strtolower($user['status']) === 'active' ? 'btn-outline-warning' : 'btn-outline-success'; ?>"
                                                title="<?php echo strtolower($user['status']) === 'active' ? 'Deactivate User' : 'Activate User'; ?>">
                                                <i
                                                    class="fas <?php echo strtolower($user['status']) === 'active' ? 'fa-user-slash' : 'fa-user-check'; ?>"></i>
                                            </button>
                                        </form>

                                        <!-- Delete User Form -->
                                        <form method="POST" action="admin_manage_users.php" class="d-inline"
                                            onsubmit="return confirm('Are you sure you want to permanently delete this user?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <button type="submit" name="delete_user"
                                                class="btn btn-sm btn-outline-danger" title="Delete User">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="fas fa-user-slash fa-2x mb-2 d-block"></i>
                                    No users matching your criteria were found.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- USER DETAILS MODAL -->
    <div class="modal fade" id="userDetailsModal" tabindex="-1" role="dialog" aria-labelledby="userDetailsModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title font-weight-bold" id="userDetailsModalLabel">
                        <i class="fas fa-user-circle mr-2"></i>User Profile & Activity Details
                    </h5>
                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body p-4">
                    <div id="modalLoading" class="text-center py-5">
                        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                            <span class="sr-only">Loading...</span>
                        </div>
                        <p class="text-muted mt-2">Fetching user information...</p>
                    </div>

                    <div id="modalContent" style="display: none;">
                        <div class="d-flex align-items-center mb-4 p-3 bg-light rounded">
                            <div class="avatar-initial mr-3" style="width: 55px; height: 55px; font-size: 1.5rem;"
                                id="mAvatar">
                                U
                            </div>
                            <div class="flex-grow-1">
                                <h4 class="mb-0 font-weight-bold text-dark" id="mFullName">User Name</h4>
                                <small class="text-muted mr-3"><i class="fas fa-envelope mr-1"></i><span
                                        id="mEmail">email@example.com</span></small>
                                <small class="text-muted"><i class="fas fa-phone mr-1"></i><span
                                        id="mPhone">N/A</span></small>
                            </div>
                            <div class="text-right">
                                <span class="badge badge-pill px-3 py-2 text-capitalize" id="mRoleBadge">Role</span>
                                <div class="mt-1"><span class="badge text-capitalize" id="mStatusBadge">Status</span>
                                </div>
                            </div>
                        </div>

                        <ul class="nav nav-tabs mb-3" id="userTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active text-dark" id="profile-tab" data-toggle="tab"
                                    href="#profileSection" role="tab">Overview & Profile</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-dark" id="questions-tab" data-toggle="tab"
                                    href="#questionsSection" role="tab">Questions Posted</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-dark" id="answers-tab" data-toggle="tab" href="#answersSection"
                                    role="tab">Answers Given</a>
                            </li>
                            <li class="nav-item" id="jobsTabLi" style="display: none;">
                                <a class="nav-link text-dark" id="jobs-tab" data-toggle="tab" href="#jobsSection"
                                    role="tab">Jobs Posted</a>
                            </li>
                        </ul>

                        <div class="tab-content" id="userTabContent">
                            <div class="tab-pane fade show active" id="profileSection" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <strong class="text-muted small d-block">Education</strong>
                                        <p class="mb-0 font-weight-bold" id="mEducation">-</p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <strong class="text-muted small d-block">Location</strong>
                                        <p class="mb-0 font-weight-bold" id="mLocation">-</p>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <strong class="text-muted small d-block">Skills</strong>
                                        <p class="mb-0 bg-light p-2 rounded" id="mSkills">-</p>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <strong class="text-muted small d-block">Bio</strong>
                                        <p class="mb-0 bg-light p-2 rounded" id="mBio">-</p>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <strong class="text-muted small d-block">Address</strong>
                                        <p class="mb-0 bg-light p-2 rounded" id="mAddress">-</p>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="questionsSection" role="tabpanel">
                                <div id="mQuestionsList"></div>
                            </div>

                            <div class="tab-pane fade" id="answersSection" role="tabpanel">
                                <div id="mAnswersList"></div>
                            </div>

                            <div class="tab-pane fade" id="jobsSection" role="tabpanel">
                                <div id="mJobsList"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary font-weight-bold" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
    $(document).ready(function() {
        $('.view-user-btn').on('click', function() {
            const userId = $(this).data('id');

            $('#modalContent').hide();
            $('#modalLoading').show();
            $('#userDetailsModal').modal('show');
            $('#userTab a:first').tab('show');

            $.ajax({
                url: 'admin_manage_users.php',
                type: 'GET',
                data: {
                    action: 'get_user_details',
                    user_id: userId
                },
                dataType: 'json',
                success: function(data) {
                    if (data.error) {
                        alert(data.error);
                        $('#userDetailsModal').modal('hide');
                        return;
                    }

                    const u = data.user;

                    $('#mAvatar').text(u.full_name.charAt(0).toUpperCase());
                    $('#mFullName').text(u.full_name);
                    $('#mEmail').text(u.email);
                    $('#mPhone').text(u.phone || 'N/A');
                    $('#mEducation').text(u.education || 'N/A');
                    $('#mLocation').text(u.location || 'N/A');
                    $('#mSkills').text(u.skills || 'None provided');
                    $('#mBio').text(u.bio || 'No bio provided.');
                    $('#mAddress').text(u.address || 'No address provided.');

                    const roleBadge = $('#mRoleBadge');
                    roleBadge.text(u.role);
                    roleBadge.removeClass(
                        'badge-role-student badge-role-instructor badge-role-expert');
                    if (u.role === 'instructor') roleBadge.addClass(
                        'badge-role-instructor');
                    else if (u.role === 'expert') roleBadge.addClass('badge-role-expert');
                    else roleBadge.addClass('badge-role-student');

                    const statusBadge = $('#mStatusBadge');
                    statusBadge.text(u.status);
                    statusBadge.removeClass('badge-success badge-danger');
                    statusBadge.addClass(u.status.toLowerCase() === 'active' ?
                        'badge-success' : 'badge-danger');

                    // Questions List
                    let qHtml = '';
                    if (data.questions && data.questions.length > 0) {
                        $.each(data.questions, function(i, q) {
                            qHtml += `<div class="border-bottom pb-2 mb-2">
                                <strong>${q.title}</strong> <span class="badge badge-info ml-2">${q.category_name}</span>
                                <small class="text-muted d-block">${new Date(q.created_at).toLocaleDateString('en-GB')}</small>
                            </div>`;
                        });
                    } else {
                        qHtml =
                            '<p class="text-center text-muted my-3">No questions asked by this user.</p>';
                    }
                    $('#mQuestionsList').html(qHtml);

                    // Answers List
                    let aHtml = '';
                    if (data.answers && data.answers.length > 0) {
                        $.each(data.answers, function(i, a) {
                            aHtml += `<div class="border-bottom pb-2 mb-2">
                                <small class="text-muted d-block">On Question: <strong>${a.question_title}</strong></small>
                                <p class="mb-1 small">${a.content}</p>
                                <small class="text-muted">${new Date(a.created_at).toLocaleDateString('en-GB')}</small>
                            </div>`;
                        });
                    } else {
                        aHtml =
                            '<p class="text-center text-muted my-3">No answers posted by this user.</p>';
                    }
                    $('#mAnswersList').html(aHtml);

                    // Jobs List
                    if (u.role === 'instructor' || u.role === 'expert') {
                        $('#jobsTabLi').show();
                        let jHtml = '';
                        if (data.jobs && data.jobs.length > 0) {
                            $.each(data.jobs, function(i, j) {
                                jHtml += `<div class="border-bottom pb-2 mb-2">
                                    <strong>${j.title}</strong> (${j.job_type})
                                    <small class="text-muted d-block">Company: ${j.company_name || 'N/A'}</small>
                                </div>`;
                            });
                        } else {
                            jHtml =
                                '<p class="text-center text-muted my-3">No job opportunities posted by this user.</p>';
                        }
                        $('#mJobsList').html(jHtml);
                    } else {
                        $('#jobsTabLi').hide();
                    }

                    $('#modalLoading').hide();
                    $('#modalContent').fadeIn();
                },
                error: function() {
                    alert('An error occurred while loading user details.');
                    $('#userDetailsModal').modal('hide');
                }
            });
        });
    });
    </script>
</body>

</html>
<?php
session_start();
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AQDesk | Answer Question Community & Knowledge Platform</title>

    <!-- Bootstrap 4.5.2 CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="./css/style.css">

    <style>
    :root {
        --primary-color: #166534;
        --secondary-color: #15803d;
        --accent-color: #eab308;
        --success-color: #22c55e;
        --light-bg: #f0fdf4;
        --dark-slate: #0f172a;
        --card-shadow: 0 8px 30px rgba(0, 0, 0, 0.07);
        --hover-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
    }

    body {
        font-family: 'Plus Jakarta Sans', sans-serif;
        background-color: var(--light-bg);
        color: var(--dark-slate);
        overflow-x: hidden;
    }

    /* ===== HERO SECTION ===== */
    .hero {
        position: relative;
        min-height: 90vh;
        background: linear-gradient(135deg, rgba(22, 101, 52, 0.92), rgba(15, 23, 42, 0.88)),
            url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') center/cover no-repeat;
        display: flex;
        align-items: center;
        color: white;
        padding: 120px 0 100px;
        overflow: hidden;
    }

    .hero::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -20%;
        width: 600px;
        height: 600px;
        background: radial-gradient(circle, rgba(234, 179, 8, 0.2) 0%, transparent 70%);
        border-radius: 50%;
        pointer-events: none;
    }

    .hero h1 {
        font-size: 3.3rem;
        font-weight: 800;
        line-height: 1.2;
        letter-spacing: -0.5px;
    }

    .hero h1 .highlight {
        color: var(--accent-color);
        position: relative;
    }

    .hero h1 .highlight::after {
        content: '';
        position: absolute;
        bottom: 2px;
        left: 0;
        width: 100%;
        height: 6px;
        background: var(--accent-color);
        opacity: 0.35;
        border-radius: 4px;
    }

    .hero p {
        font-size: 1.2rem;
        opacity: 0.92;
        max-width: 640px;
        margin: 0 auto;
    }

    .hero-badge {
        background: rgba(255, 255, 255, 0.12);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        padding: 10px 24px;
        border-radius: 50px;
        display: inline-block;
        font-weight: 600;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }

    .hero-badge i {
        color: var(--accent-color);
    }

    .btn-hero-primary {
        background: var(--accent-color);
        color: #1a1a1a;
        font-weight: 700;
        border-radius: 50px;
        padding: 16px 42px;
        transition: all 0.3s ease;
        border: none;
        box-shadow: 0 4px 20px rgba(234, 179, 8, 0.35);
        font-size: 1.05rem;
    }

    .btn-hero-primary:hover {
        background: #ca8a04;
        color: #fff;
        transform: translateY(-3px);
        box-shadow: 0 8px 30px rgba(234, 179, 8, 0.45);
    }

    .btn-hero-outline {
        background: transparent;
        color: #fff;
        font-weight: 700;
        border-radius: 50px;
        padding: 16px 42px;
        border: 2px solid rgba(255, 255, 255, 0.35);
        transition: all 0.3s ease;
        font-size: 1.05rem;
    }

    .btn-hero-outline:hover {
        background: rgba(255, 255, 255, 0.12);
        color: #fff;
        transform: translateY(-3px);
        border-color: rgba(255, 255, 255, 0.7);
    }

    /* ===== STATS SECTION ===== */
    .stats-section {
        margin-top: -50px;
        position: relative;
        z-index: 10;
    }

    .stat-card {
        background: #ffffff;
        border-radius: 20px;
        padding: 28px 20px;
        box-shadow: var(--card-shadow);
        border: 1px solid rgba(0, 0, 0, 0.04);
        text-align: center;
        transition: all 0.3s ease;
        height: 100%;
        position: relative;
        overflow: hidden;
    }

    .stat-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        border-radius: 20px 20px 0 0;
    }

    .stat-card:nth-child(1)::before {
        background: var(--primary-color);
    }

    .stat-card:nth-child(2)::before {
        background: var(--accent-color);
    }

    .stat-card:nth-child(3)::before {
        background: #3b82f6;
    }

    .stat-card:nth-child(4)::before {
        background: var(--success-color);
    }

    .stat-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--hover-shadow);
    }

    .stat-icon {
        width: 64px;
        height: 64px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6rem;
        margin: 0 auto 14px;
        background: var(--light-bg);
    }

    .stat-card:nth-child(1) .stat-icon {
        color: var(--primary-color);
    }

    .stat-card:nth-child(2) .stat-icon {
        color: var(--accent-color);
    }

    .stat-card:nth-child(3) .stat-icon {
        color: #3b82f6;
    }

    .stat-card:nth-child(4) .stat-icon {
        color: var(--success-color);
    }

    .stat-number {
        font-size: 2rem;
        font-weight: 800;
        color: var(--dark-slate);
    }

    .stat-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    /* ===== SECTION HEADINGS ===== */
    .section-title {
        font-weight: 800;
        color: var(--primary-color);
        margin-bottom: 0.5rem;
        font-size: 2.2rem;
    }

    .section-subtitle {
        color: #6b7280;
        font-size: 1.1rem;
        max-width: 620px;
        margin: 0 auto;
    }

    .section-divider {
        width: 70px;
        height: 4px;
        background: var(--accent-color);
        border-radius: 4px;
        margin: 1rem auto 0;
    }

    /* ===== FEATURE / CATEGORY / STEP CARDS ===== */
    .feature-card,
    .category-card,
    .step-card,
    .role-card {
        background: #fff;
        border-radius: 20px;
        padding: 30px 25px;
        border: 1px solid rgba(0, 0, 0, 0.04);
        height: 100%;
        transition: all 0.3s ease;
        box-shadow: var(--card-shadow);
        text-align: center;
    }

    .feature-card:hover,
    .category-card:hover,
    .step-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--hover-shadow);
    }

    .feature-icon-box,
    .category-icon {
        width: 64px;
        height: 64px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin: 0 auto 16px;
        background: var(--light-bg);
        color: var(--primary-color);
        transition: all 0.3s ease;
    }

    .feature-card:hover .feature-icon-box,
    .category-card:hover .category-icon {
        background: var(--primary-color);
        color: #fff;
        transform: scale(1.05);
    }

    .step-number {
        width: 42px;
        height: 42px;
        background: var(--primary-color);
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        margin: 0 auto 14px;
        transition: all 0.3s ease;
    }

    .step-card:hover .step-number {
        background: var(--accent-color);
        color: #1a1a1a;
        transform: scale(1.1);
    }

    .step-number.done {
        background: var(--success-color);
    }

    .role-card {
        text-align: left;
        border-left: 5px solid var(--secondary-color);
    }

    .role-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--hover-shadow);
    }

    /* ===== CTA BANNER ===== */
    .cta-banner {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        border-radius: 24px;
        padding: 60px 50px;
        color: #fff;
        position: relative;
        overflow: hidden;
    }

    .cta-banner::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: 400px;
        height: 400px;
        background: radial-gradient(circle, rgba(234, 179, 8, 0.25) 0%, transparent 70%);
        border-radius: 50%;
    }

    .btn-cta-primary {
        background: var(--accent-color);
        color: #1a1a1a;
        font-weight: 700;
        border-radius: 50px;
        padding: 14px 36px;
        border: none;
        transition: all 0.3s ease;
        position: relative;
        z-index: 1;
    }

    .btn-cta-primary:hover {
        background: #ca8a04;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(234, 179, 8, 0.4);
        color: #fff;
    }

    .btn-cta-outline {
        background: transparent;
        color: #fff;
        font-weight: 700;
        border-radius: 50px;
        padding: 14px 36px;
        border: 2px solid rgba(255, 255, 255, 0.35);
        transition: all 0.3s ease;
        position: relative;
        z-index: 1;
    }

    .btn-cta-outline:hover {
        background: rgba(255, 255, 255, 0.12);
        border-color: rgba(255, 255, 255, 0.7);
        color: #fff;
    }

    /* ===== FOOTER ===== */
    footer {
        background: var(--dark-slate) !important;
        border-top: 4px solid var(--accent-color);
    }

    footer a {
        color: rgba(255, 255, 255, 0.6);
        text-decoration: none;
        transition: color 0.2s;
        font-size: 0.9rem;
    }

    footer a:hover {
        color: var(--accent-color);
        text-decoration: none;
    }

    /* ===== RESPONSIVE ===== */
    @media (max-width: 768px) {
        .hero {
            min-height: 75vh;
            padding: 90px 0 70px;
        }

        .hero h1 {
            font-size: 2.2rem;
        }

        .section-title {
            font-size: 1.8rem;
        }

        .cta-banner {
            padding: 40px 25px;
        }

        .stats-section {
            margin-top: -25px;
        }
    }
    </style>
</head>

<body>

    <?php include('navbar.php'); ?>

    <!-- ============================================================ -->
    <!-- 1. HERO SECTION                                               -->
    <!-- ============================================================ -->
    <section class="hero text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9 col-xl-8">
                    <div class="hero-badge mb-4">
                        <i class="fas fa-comments mr-2"></i> Ask • Learn • Collaborate
                    </div>
                    <h1 class="mb-4 text-white">
                        AQDesk<br>
                        <span class="highlight">Answer Question Community Platform</span>
                    </h1>
                    <p class="mb-5">
                        A digital community and knowledge-sharing platform for students, instructors, researchers,
                        and technology professionals. Ask questions, share expertise, collaborate on projects,
                        and explore career opportunities in Emerging Technologies.
                    </p>
                    <div class="d-flex flex-wrap justify-content-center">
                        <a href="register.php" class="btn btn-hero-primary mx-2 mb-3">
                            <i class="fas fa-user-plus mr-2"></i>Get Started Free
                        </a>
                        <a href="login.php" class="btn btn-hero-outline mx-2 mb-3">
                            <i class="fas fa-sign-in-alt mr-2"></i>Login to Account
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 2. LIVE STATS (Dummy Data)                                    -->
    <!-- ============================================================ -->
    <section class="stats-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-6 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-users"></i></div>
                        <div class="stat-number">1,250</div>
                        <div class="stat-label">Active Members</div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-question-circle"></i></div>
                        <div class="stat-number">3,480</div>
                        <div class="stat-label">Questions Asked</div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-comment-dots"></i></div>
                        <div class="stat-number">8,920</div>
                        <div class="stat-label">Answers Posted</div>
                    </div>
                </div>
                <div class="col-md-3 col-6 mb-3">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-briefcase"></i></div>
                        <div class="stat-number">215</div>
                        <div class="stat-label">Jobs & Internships</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 3. KEY FEATURES                                               -->
    <!-- ============================================================ -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Why Choose AQDesk?</h2>
                <p class="section-subtitle">Everything students, instructors and experts need for knowledge sharing and
                    professional growth</p>
                <div class="section-divider"></div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-question-circle"></i></div>
                        <h5>Community Q&A</h5>
                        <p>Ask questions, post answers, upvote helpful responses, and tag topics for better discovery.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-user-graduate"></i></div>
                        <h5>Role-Based Access</h5>
                        <p>Secure registration with different roles — Student, Instructor, Expert and Admin.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-briefcase"></i></div>
                        <h5>Jobs & Internships</h5>
                        <p>Discover career opportunities, apply for jobs and internships posted by experts and
                            organizations.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-project-diagram"></i></div>
                        <h5>Project Collaboration</h5>
                        <p>Create project spaces, invite collaborators, share files and give feedback easily.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-chalkboard-teacher"></i></div>
                        <h5>Expert Knowledge</h5>
                        <p>Learn directly from instructors and technology experts through answers and discussions.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="feature-card">
                        <div class="feature-icon-box"><i class="fas fa-user-circle"></i></div>
                        <h5>User Profiles</h5>
                        <p>Build your professional profile, showcase skills, education and contributions to the
                            community.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 4. CATEGORIES                                                 -->
    <!-- ============================================================ -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Popular Knowledge Categories</h2>
                <p class="section-subtitle">Explore questions and discussions across emerging technology domains</p>
                <div class="section-divider"></div>
            </div>

            <div class="row">
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="category-card">
                        <div class="category-icon"><i class="fas fa-laptop-code"></i></div>
                        <h5>EdTech</h5>
                        <p>Educational Technology, Learning Platforms and Digital Education tools.</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="category-card">
                        <div class="category-icon"><i class="fas fa-brain"></i></div>
                        <h5>Artificial Intelligence</h5>
                        <p>Machine Learning, Deep Learning, AI applications and research discussions.</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="category-card">
                        <div class="category-icon"><i class="fas fa-code"></i></div>
                        <h5>Web Development</h5>
                        <p>Frontend, Backend, Full-stack development and modern web technologies.</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <div class="category-card">
                        <div class="category-icon"><i class="fas fa-globe"></i></div>
                        <h5>Internet Governance</h5>
                        <p>Digital policies, cybersecurity, data privacy and internet regulations.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 5. HOW IT WORKS                                               -->
    <!-- ============================================================ -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">How AQDesk Works</h2>
                <p class="section-subtitle">A simple process from asking questions to growing your career</p>
                <div class="section-divider"></div>
            </div>

            <div class="row">
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number">1</div>
                        <h6 class="text-success">Register</h6>
                        <p>Create a free account as Student, Instructor or Expert.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number">2</div>
                        <h6 class="text-success">Ask Questions</h6>
                        <p>Post your questions with relevant categories and tags.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number">3</div>
                        <h6 class="text-success">Get Answers</h6>
                        <p>Receive helpful answers from the community and experts.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number">4</div>
                        <h6 class="text-success">Upvote & Learn</h6>
                        <p>Upvote the best answers and mark them as accepted.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number">5</div>
                        <h6 class="text-success">Explore Jobs</h6>
                        <p>Browse internships and job opportunities shared by experts.</p>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 mb-4">
                    <div class="step-card">
                        <div class="step-number done">6</div>
                        <h6 class="text-success">Grow & Collaborate</h6>
                        <p>Build your profile and collaborate on real projects.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 6. USER ROLES                                                 -->
    <!-- ============================================================ -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title">Who Can Use AQDesk?</h2>
                <p class="section-subtitle">Built for students, instructors, experts and platform administrators</p>
                <div class="section-divider"></div>
            </div>

            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="role-card" style="border-left-color: var(--primary-color);">
                        <span class="h3 text-success"><i class="fas fa-user-graduate"></i></span>
                        <h5 class="mt-2">Students</h5>
                        <p>Ask questions, learn from answers, build your profile, apply for internships and collaborate
                            on projects.</p>
                        <a href="register.php"
                            class="btn btn-sm btn-outline-success font-weight-bold rounded-pill px-3">
                            Register as Student →
                        </a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="role-card" style="border-left-color: var(--accent-color);">
                        <span class="h3 text-warning"><i class="fas fa-chalkboard-teacher"></i></span>
                        <h5 class="mt-2">Instructors & Experts</h5>
                        <p>Share knowledge, answer questions, post job opportunities and guide the next generation of
                            technologists.</p>
                        <a href="register.php"
                            class="btn btn-sm btn-outline-warning font-weight-bold rounded-pill px-3">
                            Register as Expert →
                        </a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="role-card" style="border-left-color: #3b82f6;">
                        <span class="h3 text-primary"><i class="fas fa-user-shield"></i></span>
                        <h5 class="mt-2">Admin</h5>
                        <p>Manage users, moderate content, oversee jobs and ensure a healthy knowledge-sharing
                            environment.</p>
                        <a href="login.php" class="btn btn-sm btn-outline-primary font-weight-bold rounded-pill px-3">
                            Admin Login →
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 7. CTA BANNER                                                 -->
    <!-- ============================================================ -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="cta-banner text-center">
                <h2 class="mb-3 text-white">Ready to Start Learning & Sharing?</h2>
                <p class="mb-4 opacity-90">
                    Join AQDesk today. Ask questions, get expert answers, discover opportunities,
                    and grow with a community of learners and professionals.
                </p>
                <div>
                    <a href="register.php" class="btn btn-cta-primary mx-2 mb-2">
                        <i class="fas fa-rocket mr-2"></i>Create Free Account
                    </a>
                    <a href="login.php" class="btn btn-cta-outline mx-2 mb-2">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login Now
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================ -->
    <!-- 8. FOOTER                                                     -->
    <!-- ============================================================ -->
    <footer class="text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4 mb-lg-0">
                    <h4 class="font-weight-bold text-white mb-3">
                        <i class="fas fa-comments mr-2 text-warning"></i>AQDesk
                    </h4>
                    <p class="text-white-50 small" style="line-height: 1.8;">
                        A digital community and knowledge-sharing platform designed to support learning,
                        collaboration, and professional development in Emerging Technologies.
                    </p>
                </div>
                <div class="col-6 col-md-4 col-lg-2 mb-4">
                    <h6 class="font-weight-bold text-white mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="index.php">Home</a></li>
                        <li class="mb-2"><a href="login.php">Login</a></li>
                        <li class="mb-2"><a href="register.php">Register</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md-4 col-lg-3 mb-4">
                    <h6 class="font-weight-bold text-white mb-3">Categories</h6>
                    <ul class="list-unstyled text-white-50 small">
                        <li class="mb-2">EdTech</li>
                        <li class="mb-2">Artificial Intelligence</li>
                        <li class="mb-2">Web Development</li>
                        <li class="mb-2">Internet Governance</li>
                    </ul>
                </div>
                <div class="col-md-4 col-lg-3 mb-4">
                    <h6 class="font-weight-bold text-white mb-3">Supervisor</h6>
                    <ul class="list-unstyled text-white-50 small">
                        <li class="mb-2"><i class="fas fa-user mr-2 text-warning"></i>Mr. Abdullah Qamar</li>
                        <li class="mb-2"><i class="fas fa-envelope mr-2 text-warning"></i>abdullah.qamar@vu.edu.pk</li>
                        <li class="mb-2"><i class="fas fa-university mr-2 text-warning"></i>Virtual University of
                            Pakistan</li>
                    </ul>
                </div>
            </div>

            <hr style="border-color: rgba(255,255,255,0.08); margin: 2rem 0 1.5rem;">

            <div class="text-center">
                <p class="text-white-50 small mb-0">
                    &copy; <?= date('Y'); ?> AQDesk – Answer Question Community Platform. All Rights Reserved.<br>
                    Final Year Project — Powered by PHP, MySQL & Bootstrap | Virtual University of Pakistan
                </p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
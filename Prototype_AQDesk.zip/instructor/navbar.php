<!-- Navigation Bar -->
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="instructor_dashboard.php">Instructor Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="instructor_dashboard.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="update_profile.php">Update Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ask_question.php">Ask Question</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="questions.php">View Questions</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_jobs.php"> Jobs</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>
<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"]) || !in_array(strtolower($_SESSION["role"]), ['instructor', 'expert'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$msg = "";
$type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title                = trim($_POST['title']);
    $company_name         = trim($_POST['company_name']);
    $location             = trim($_POST['location']);
    $job_type             = $_POST['job_type'];
    $description          = trim($_POST['description']);
    $requirements         = trim($_POST['requirements']);
    $salary_range         = trim($_POST['salary_range']);
    $application_deadline = !empty($_POST['application_deadline']) ? $_POST['application_deadline'] : NULL;

    if (empty($title) || empty($description)) {
        $msg = "Title and Description are required fields.";
        $type = "danger";
    } else {
        $sql = "INSERT INTO jobs (posted_by, title, company_name, location, job_type, description, requirements, salary_range, application_deadline) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "issssssss", $user_id, $title, $company_name, $location, $job_type, $description, $requirements, $salary_range, $application_deadline);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header("Location: view_jobs.php?msg=added");
            exit();
        } else {
            $msg = "Failed to post job. Please try again.";
            $type = "danger";
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Job / Opportunity - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm border-0" style="border-radius: 12px;">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Post a New Opportunity</h3>

                        <?php if ($msg): ?>
                        <div class="alert alert-<?= $type ?> text-center">
                            <?= htmlspecialchars($msg) ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="add_job.php">

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Job Title *</label>
                                    <input type="text" name="title" class="form-control"
                                        placeholder="e.g. Senior PHP Developer" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Company / Organization Name</label>
                                    <input type="text" name="company_name" class="form-control"
                                        placeholder="e.g. Tech Solutions Inc.">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Job Type *</label>
                                    <select name="job_type" class="form-control" required>
                                        <option value="full-time">Full-Time</option>
                                        <option value="part-time">Part-Time</option>
                                        <option value="internship">Internship</option>
                                        <option value="contract">Contract</option>
                                        <option value="remote">Remote</option>
                                    </select>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Location</label>
                                    <input type="text" name="location" class="form-control"
                                        placeholder="e.g. New York / Remote">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Salary Range</label>
                                    <input type="text" name="salary_range" class="form-control"
                                        placeholder="e.g. $50,000 - $70,000 / year">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Application Deadline</label>
                                    <input type="date" name="application_deadline" class="form-control">
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Job Description *</label>
                                <textarea name="description" class="form-control" rows="5"
                                    placeholder="Detailed job responsibilities and overview..." required></textarea>
                            </div>

                            <div class="form-group">
                                <label>Requirements & Qualifications</label>
                                <textarea name="requirements" class="form-control" rows="4"
                                    placeholder="Key skills, education, experience required..."></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block mt-4">Post Opportunity</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
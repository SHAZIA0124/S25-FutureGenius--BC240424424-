<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$msg = "";
$type = "";

// Fetch current user data
$sql = "SELECT full_name, email, phone, bio, education, skills, location, address, role FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $phone     = trim($_POST['phone']);
    $bio       = trim($_POST['bio']);
    $education = trim($_POST['education']);
    $skills    = trim($_POST['skills']);
    $location  = trim($_POST['location']);
    $address   = trim($_POST['address']);

    $update_sql = "UPDATE users SET full_name = ?, phone = ?, bio = ?, education = ?, skills = ?, location = ?, address = ? WHERE id = ?";
    $update_stmt = mysqli_prepare($conn, $update_sql);
    mysqli_stmt_bind_param($update_stmt, "sssssssi", $full_name, $phone, $bio, $education, $skills, $location, $address, $user_id);

    if (mysqli_stmt_execute($update_stmt)) {
        $_SESSION["full_name"] = $full_name;
        $msg = "Profile updated successfully!";
        $type = "success";
        
        // Refresh local user data
        $user['full_name'] = $full_name;
        $user['phone']     = $phone;
        $user['bio']       = $bio;
        $user['education'] = $education;
        $user['skills']    = $skills;
        $user['location']  = $location;
        $user['address']   = $address;
    } else {
        $msg = "Failed to update profile. Please try again.";
        $type = "danger";
    }
    mysqli_stmt_close($update_stmt);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php if(file_exists('navbar.php')) include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm border-0" style="border-radius: 12px;">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Edit Profile Information</h3>

                        <?php if ($msg): ?>
                        <div class="alert alert-<?= $type ?> text-center">
                            <?= htmlspecialchars($msg) ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="update_profile.php">

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Full Name *</label>
                                    <input type="text" name="full_name" class="form-control" required
                                        value="<?= htmlspecialchars($user['full_name'] ?? '') ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Email Address (Read-only)</label>
                                    <input type="email" class="form-control bg-light" readonly
                                        value="<?= htmlspecialchars($user['email'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Role</label>
                                    <input type="text" class="form-control bg-light text-capitalize" readonly
                                        value="<?= htmlspecialchars($user['role'] ?? '') ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Phone</label>
                                    <input type="text" name="phone" class="form-control"
                                        value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Location</label>
                                    <input type="text" name="location" class="form-control"
                                        value="<?= htmlspecialchars($user['location'] ?? '') ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Education</label>
                                    <input type="text" name="education" class="form-control"
                                        value="<?= htmlspecialchars($user['education'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>Skills (Comma-separated)</label>
                                    <input type="text" name="skills" class="form-control"
                                        value="<?= htmlspecialchars($user['skills'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>Bio</label>
                                    <textarea name="bio" class="form-control"
                                        rows="3"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>Address</label>
                                    <textarea name="address" class="form-control"
                                        rows="2"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block mt-4">Save Changes</button>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
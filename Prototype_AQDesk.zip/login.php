<?php
session_start();
include('config.php');

$email = $password = $usertype = "";
$email_err = $password_err = $usertype_err = "";
$login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty(trim($_POST["usertype"]))) {
        $usertype_err = "Please select your account type.";
    } else {
        $usertype = trim($_POST["usertype"]);
    }

    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } else {
        $email = trim($_POST["email"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $password = trim($_POST["password"]);
    }

    if (empty($email_err) && empty($password_err) && empty($usertype_err)) {

        $sql = "SELECT id, full_name, email, password, role, status FROM users WHERE email = ?";
        
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $email);

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $user_id, $full_name, $email_db, $hashed_password, $role_db, $status);

                    if (mysqli_stmt_fetch($stmt)) {
                        
                        if (strtolower($usertype) !== strtolower($role_db)) {
                            $login_err = "Account exists, but not as a " . ucfirst($usertype) . ". Please select the correct role.";
                        } 
                        elseif (strtolower($status) === 'deactive') {
                            $login_err = "Your account is deactivated. Please contact support.";
                        } 
                        elseif (password_verify($password, $hashed_password)) {

                            session_regenerate_id(true);

                            $_SESSION["user_id"]   = $user_id;
                            $_SESSION["full_name"] = $full_name;
                            $_SESSION["email"]     = $email_db;
                            $_SESSION["role"]      = strtolower($role_db);

                            // Dynamic Redirection based on Role
                            $user_role = strtolower($role_db);
                            if ($user_role === 'student') {
                                header("Location: student/student_dashboard.php");
                            } elseif ($user_role === 'instructor') {
                                header("Location: instructor/instructor_dashboard.php");
                            } elseif ($user_role === 'expert') {
                                header("Location: expert/expert_dashboard.php");
                            } else {
                                header("Location: index.php");
                            }
                            exit();

                        } else {
                            $login_err = "Invalid email or password.";
                        }
                    }
                } else {
                    $login_err = "Invalid email or password.";
                }
            } else {
                $login_err = "Database query failed. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login - AQDesk</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>

<body class="bg-light">

    <?php if(file_exists('navbar.php')) include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-7">
                <div class="card shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
                    <div class="card-body p-4">

                        <h3 class="text-center mb-2">AQDesk Login</h3>
                        <p class="text-center text-muted mb-4">Select your role and sign in to continue</p>

                        <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                            <?php if (!empty($login_err)): ?>
                            <div class="alert alert-danger text-center">
                                <?= htmlspecialchars($login_err) ?>
                            </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label>Login As *</label>
                                <select name="usertype"
                                    class="form-control <?= !empty($usertype_err) ? 'is-invalid' : '' ?>">
                                    <option value="">-- Select Role --</option>
                                    <option value="student" <?= ($usertype === "student") ? 'selected' : '' ?>>Student
                                    </option>
                                    <option value="instructor" <?= ($usertype === "instructor") ? 'selected' : '' ?>>
                                        Instructor</option>
                                    <option value="expert" <?= ($usertype === "expert") ? 'selected' : '' ?>>Expert
                                    </option>
                                </select>
                                <span class="invalid-feedback"><?= $usertype_err ?></span>
                            </div>

                            <div class="form-group">
                                <label>Email Address *</label>
                                <input type="email" name="email"
                                    class="form-control <?= !empty($email_err) ? 'is-invalid' : '' ?>"
                                    value="<?= htmlspecialchars($email) ?>" placeholder="example@mail.com">
                                <span class="invalid-feedback"><?= $email_err ?></span>
                            </div>

                            <div class="form-group">
                                <label>Password *</label>
                                <input type="password" name="password"
                                    class="form-control <?= !empty($password_err) ? 'is-invalid' : '' ?>"
                                    placeholder="Enter password">
                                <span class="invalid-feedback"><?= $password_err ?></span>
                            </div>

                            <div class="form-group text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-block">Login</button>
                            </div>

                        </form>

                        <div class="text-center mt-3">
                            <p class="mb-1">Don't have an account?</p>
                            <a href="register.php" class="btn btn-outline-primary btn-sm">Create New Account</a>
                            <p class="mt-3 mb-0"><a href="index.php">← Back to Home</a></p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>
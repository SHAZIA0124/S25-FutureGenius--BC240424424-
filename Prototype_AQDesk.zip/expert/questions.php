<?php
session_start();
include('config.php');

$category_filter = isset($_GET['category']) ? intval($_GET['category']) : 0;

$sql = "SELECT q.id, q.title, q.content, q.created_at, u.full_name, c.name AS category_name,
        (SELECT COUNT(*) FROM answers a WHERE a.question_id = q.id) AS answer_count
        FROM questions q
        JOIN users u ON q.user_id = u.id
        JOIN categories c ON q.category_id = c.id";

if ($category_filter > 0) {
    $sql .= " WHERE q.category_id = " . $category_filter;
}

$sql .= " ORDER BY q.created_at DESC";
$result = mysqli_query($conn, $sql);

$categories_result = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Community Q&A - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php  include('navbar.php'); ?>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Community Questions</h2>
            <?php if(isset($_SESSION['user_id'])): ?>
            <a href="ask_question.php" class="btn btn-primary"><i class="fas fa-plus mr-1"></i> Ask Question</a>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white font-weight-bold">Categories</div>
                    <div class="list-group list-group-flush">
                        <a href="questions.php"
                            class="list-group-item list-group-item-action <?= $category_filter == 0 ? 'active' : '' ?>">All
                            Categories</a>
                        <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                        <a href="questions.php?category=<?= $cat['id'] ?>"
                            class="list-group-item list-group-item-action <?= $category_filter == $cat['id'] ? 'active' : '' ?>">
                            <?= htmlspecialchars($cat['name']) ?>
                        </a>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
                <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($q = mysqli_fetch_assoc($result)): ?>
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <span class="badge badge-info mb-2"><?= htmlspecialchars($q['category_name']) ?></span>
                            <small class="text-muted"><i class="far fa-clock"></i>
                                <?= date('d M Y, h:i A', strtotime($q['created_at'])) ?></small>
                        </div>
                        <h5 class="card-title">
                            <a href="question_detail.php?id=<?= $q['id'] ?>"
                                class="text-dark font-weight-bold"><?= htmlspecialchars($q['title']) ?></a>
                        </h5>
                        <p class="card-text text-muted"><?= htmlspecialchars(substr($q['content'], 0, 150)) ?>...</p>
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                            <small class="text-muted">Asked by
                                <strong><?= htmlspecialchars($q['full_name']) ?></strong></small>
                            <span class="badge badge-light border"><i class="far fa-comment"></i>
                                <?= $q['answer_count'] ?> Answers</span>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
                <?php else: ?>
                <div class="alert alert-info text-center">No questions found in this category.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>

</html>
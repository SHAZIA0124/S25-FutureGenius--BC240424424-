-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2026 at 09:06 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prototype_aqdesk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'Testuser12', '123');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `is_accepted` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `user_id`, `content`, `is_accepted`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'First check your .env file. Make sure DB_HOST, DB_DATABASE, DB_USERNAME and DB_PASSWORD are correct. Also run `php artisan config:clear` after changing .env.', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(2, 1, 3, 'Another common issue is using wrong port. Default MySQL port is 3306. Also make sure MySQL service is running.', 0, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(3, 2, 3, 'AI is the broader concept of machines performing tasks that require human intelligence. Machine Learning is a subset of AI where systems learn from data. Deep Learning is a further subset that uses neural networks.', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(4, 2, 1, 'Simple example: AI can be a chess-playing computer. Machine Learning is when it improves by playing many games. Deep Learning is when it uses multi-layer neural networks for complex pattern recognition.', 0, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(5, 3, 3, 'Focus on clean UI, accessibility (WCAG), mobile responsiveness, and personalized learning paths. Also implement strong user roles and progress tracking.', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(6, 4, 1, 'Major challenges include limited digital infrastructure, lack of skilled policy makers, low digital literacy, and weak regulatory frameworks.', 0, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(7, 4, 3, 'In addition, issues like data privacy, cybersecurity threats, and influence of big tech companies make Internet Governance more complex in developing nations.', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(8, 5, 1, 'Both are excellent. React has larger job market currently, but Vue.js is easier to learn and very productive. For beginners, I recommend Vue.js first.', 0, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(9, 5, 3, 'In 2026, React still dominates the industry. However, if you like clean and simple syntax, Vue.js is great. Learn the fundamentals of JavaScript deeply first.', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `answer_votes`
--

CREATE TABLE `answer_votes` (
  `id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vote_type` enum('upvote','downvote') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `answer_votes`
--

INSERT INTO `answer_votes` (`id`, `answer_id`, `user_id`, `vote_type`, `created_at`) VALUES
(1, 1, 2, 'upvote', '2026-08-13 06:44:30'),
(2, 1, 3, 'upvote', '2026-08-13 06:44:30'),
(3, 2, 2, 'upvote', '2026-08-13 06:44:30'),
(4, 3, 1, 'upvote', '2026-08-13 06:44:30'),
(5, 3, 2, 'upvote', '2026-08-13 06:44:30'),
(6, 4, 2, 'upvote', '2026-08-13 06:44:30'),
(7, 5, 2, 'upvote', '2026-08-13 06:44:30'),
(8, 5, 1, 'upvote', '2026-08-13 06:44:30'),
(9, 6, 2, 'upvote', '2026-08-13 06:44:30'),
(10, 7, 1, 'upvote', '2026-08-13 06:44:30'),
(11, 7, 2, 'upvote', '2026-08-13 06:44:30'),
(12, 8, 2, 'upvote', '2026-08-13 06:44:30'),
(13, 9, 1, 'upvote', '2026-08-13 06:44:30'),
(14, 9, 2, 'upvote', '2026-08-13 06:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(1, 'EdTech', '2026-08-13 06:20:52'),
(2, 'Artificial Intelligence', '2026-08-13 06:20:52'),
(3, 'Web Development', '2026-08-13 06:20:52'),
(4, 'Internet Governance', '2026-08-13 06:20:52');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `posted_by` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `job_type` enum('full-time','part-time','internship','contract','remote') DEFAULT 'full-time',
  `description` text NOT NULL,
  `requirements` text DEFAULT NULL,
  `salary_range` varchar(100) DEFAULT NULL,
  `application_deadline` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `posted_by`, `title`, `company_name`, `location`, `job_type`, `description`, `requirements`, `salary_range`, `application_deadline`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'Junior Web Developer', 'TechVision Solutions', 'Lahore', 'full-time', 'We are looking for a motivated Junior Web Developer to join our team and work on educational web platforms.', 'Basic knowledge of HTML, CSS, JavaScript, PHP. Fresh graduates are encouraged to apply.', '40,000 - 60,000 PKR', '2026-09-30', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(2, 1, 'Laravel Intern', 'EduSoft Pvt Ltd', 'Karachi', 'internship', '3-month internship opportunity for students interested in Laravel development.', 'Familiarity with PHP and MySQL. Basic understanding of MVC architecture preferred.', 'Stipend: 15,000 PKR', '2026-09-15', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(3, 1, 'Frontend Developer (Vue.js)', 'Digital Classroom', 'Remote', 'remote', 'Looking for a frontend developer experienced in Vue.js to build interactive learning interfaces.', 'Strong knowledge of Vue.js, JavaScript, and responsive design.', '80,000 - 120,000 PKR', '2026-10-10', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(4, 1, 'Database Assistant', 'SmartLearn Technologies', 'Islamabad', 'part-time', 'Part-time role to help maintain and optimize MySQL databases for e-learning systems.', 'Good understanding of MySQL, basic queries, and database design.', '25,000 - 35,000 PKR', '2026-09-20', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(5, 1, 'Teaching Assistant - Web Development', 'Virtual University Partner', 'Lahore', 'part-time', 'Support instructors in conducting web development courses and helping students with practical tasks.', 'Strong communication skills and good knowledge of web technologies.', '30,000 PKR', '2026-09-25', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(6, 3, 'Machine Learning Engineer', 'AI Nexus Labs', 'Islamabad', 'full-time', 'Join our AI team to develop intelligent systems for educational and research purposes.', 'Strong knowledge of Python, Machine Learning, and data analysis. Experience with TensorFlow or PyTorch preferred.', '150,000 - 250,000 PKR', '2026-10-15', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(7, 3, 'AI Research Intern', 'FutureTech Research', 'Remote', 'internship', 'Internship opportunity for students interested in Artificial Intelligence research.', 'Basic understanding of AI/ML concepts. Python programming skills required.', 'Stipend: 20,000 PKR', '2026-09-18', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(8, 3, 'Data Analyst', 'Insight Analytics', 'Karachi', 'full-time', 'Analyze educational and user data to generate meaningful insights for decision making.', 'Knowledge of SQL, Excel, and basic Python/R. Strong analytical skills.', '70,000 - 100,000 PKR', '2026-10-05', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(9, 3, 'AI Consultant (Contract)', 'SmartGov Solutions', 'Islamabad', 'contract', 'Short-term contract to advise on AI implementation in public sector digital projects.', 'Proven experience in AI consulting and understanding of digital governance.', 'Project-based', '2026-09-30', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(10, 3, 'Deep Learning Specialist', 'NeuroTech AI', 'Lahore', 'full-time', 'Work on advanced deep learning models for real-world applications in education and healthcare.', 'Experience with neural networks, Python, and modern DL frameworks.', '200,000 - 300,000 PKR', '2026-10-20', 1, '2026-08-13 06:44:30', '2026-08-13 06:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `category_id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 2, 3, 'How to connect Laravel with MySQL properly?', 'I am building a project in Laravel and facing issues while connecting to MySQL database. Can someone guide me with the correct .env configuration and common mistakes?', '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(2, 2, 2, 'What is the difference between AI and Machine Learning?', 'I am new to Artificial Intelligence. Can someone explain the clear difference between AI, Machine Learning, and Deep Learning with simple examples?', '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(3, 1, 1, 'Best practices for designing an EdTech platform?', 'I am working on an educational technology platform. What are the key design and technical best practices we should follow for better student engagement?', '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(4, 3, 4, 'Challenges in Internet Governance in developing countries?', 'What are the major challenges faced by developing countries in implementing effective Internet Governance policies?', '2026-08-13 06:44:30', '2026-08-13 06:44:30'),
(5, 2, 3, 'Should I learn Vue.js or React in 2026?', 'I already know basic JavaScript. For a full-stack developer career, which frontend framework should I focus on in 2026 — Vue.js or React?', '2026-08-13 06:44:30', '2026-08-13 06:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','instructor','expert') NOT NULL DEFAULT 'student',
  `phone` varchar(20) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` enum('active','deactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `role`, `phone`, `bio`, `education`, `skills`, `location`, `address`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Prof. Usman Raza', 'usman.instructor@example.com', '$2y$10$sviBQP0h8IekrUcvMitkoeGDFd3vO2eeUcrVcAbMAm.gvsRyBy6wS', 'instructor', '03111222333', 'Experienced university instructor specializing in Web Development, Database Systems, and Emerging Technologies. Passionate about guiding students in practical software development.', 'MS Software Engineering', 'PHP, Laravel, MySQL, JavaScript, Vue.js, System Design, Mentoring', 'Karachi', 'Gulshan-e-Iqbal, Karachi', 'active', '2026-08-13 06:17:05', '2026-08-13 06:40:02'),
(2, 'Ali Khan', 'ali.student@example.com', '$2y$10$sviBQP0h8IekrUcvMitkoeGDFd3vO2eeUcrVcAbMAm.gvsRyBy6wS', 'student', '03001234567', 'Passionate computer science student interested in AI and Web Development.', 'BS Computer Science', 'HTML, CSS, JavaScript, PHP, MySQL', 'Lahore', 'Model Town, Lahore', 'active', '2026-08-13 06:39:29', '2026-08-13 06:39:29'),
(3, 'Dr. Sara Ahmed', 'sara.expert@example.com', '$2y$10$sviBQP0h8IekrUcvMitkoeGDFd3vO2eeUcrVcAbMAm.gvsRyBy6wS', 'expert', '03219876543', 'AI researcher and technology consultant with 10+ years of experience.', 'PhD in Artificial Intelligence', 'Machine Learning, Deep Learning, Python, Data Science', 'Islamabad', 'F-10, Islamabad', 'active', '2026-08-13 06:39:29', '2026-08-13 06:39:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `answer_votes`
--
ALTER TABLE `answer_votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_answer_vote` (`answer_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posted_by` (`posted_by`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `answer_votes`
--
ALTER TABLE `answer_votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `answer_votes`
--
ALTER TABLE `answer_votes`
  ADD CONSTRAINT `answer_votes_ibfk_1` FOREIGN KEY (`answer_id`) REFERENCES `answers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `answer_votes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`posted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

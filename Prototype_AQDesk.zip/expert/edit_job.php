<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"]) || !in_array(strtolower($_SESSION["role"]), ['instructor', 'expert', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$user_role = strtolower($_SESSION["role"]);
$job_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$msg = "";
$type = "";

$sql = "SELECT * FROM jobs WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $job_id);
mysqli_stmt_execute($stmt);
$job = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$job || ($job['posted_by'] != $user_id && $user_role !== 'admin')) {
    header("Location: view_jobs.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title                = trim($_POST['title']);
    $company_name         = trim($_POST['company_name']);
    $location             = trim($_POST['location']);
    $job_type             = $_POST['job_type'];
    $description          = trim($_POST['description']);
    $requirements         = trim($_POST['requirements']);
    $salary_range         = trim($_POST['salary_range']);
    $application_deadline = !empty($_POST['application_deadline']) ? $_POST['application_deadline'] : NULL;

    if (empty($title) || empty($description)) {
        $msg = "Title and Description are required fields.";
        $type = "danger";
    } else {
        $update_sql = "UPDATE jobs SET title = ?, company_name = ?, location = ?, job_type = ?, description = ?, requirements = ?, salary_range = ?, application_deadline = ? WHERE id = ?";
        $update_stmt = mysqli_prepare($conn, $update_sql);
        mysqli_stmt_bind_param($update_stmt, "ssssssssi", $title, $company_name, $location, $job_type, $description, $requirements, $salary_range, $application_deadline, $job_id);

        if (mysqli_stmt_execute($update_stmt)) {
            mysqli_stmt_close($update_stmt);
            header("Location: view_jobs.php?msg=updated");
            exit();
        } else {
            $msg = "Failed to update job details.";
            $type = "danger";
            mysqli_stmt_close($update_stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job / Opportunity - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php   include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm border-0" style="border-radius: 12px;">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Edit Opportunity Listing</h3>

                        <?php if ($msg): ?>
                        <div class="alert alert-<?= $type ?> text-center">
                            <?= htmlspecialchars($msg) ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="edit_job.php?id=<?= $job_id ?>">

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Job Title *</label>
                                    <input type="text" name="title" class="form-control" required
                                        value="<?= htmlspecialchars($job['title']) ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Company / Organization Name</label>
                                    <input type="text" name="company_name" class="form-control"
                                        value="<?= htmlspecialchars($job['company_name'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Job Type *</label>
                                    <select name="job_type" class="form-control" required>
                                        <option value="full-time"
                                            <?= $job['job_type'] === 'full-time' ? 'selected' : '' ?>>Full-Time</option>
                                        <option value="part-time"
                                            <?= $job['job_type'] === 'part-time' ? 'selected' : '' ?>>Part-Time</option>
                                        <option value="internship"
                                            <?= $job['job_type'] === 'internship' ? 'selected' : '' ?>>Internship
                                        </option>
                                        <option value="contract"
                                            <?= $job['job_type'] === 'contract' ? 'selected' : '' ?>>Contract</option>
                                        <option value="remote" <?= $job['job_type'] === 'remote' ? 'selected' : '' ?>>
                                            Remote</option>
                                    </select>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Location</label>
                                    <input type="text" name="location" class="form-control"
                                        value="<?= htmlspecialchars($job['location'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Salary Range</label>
                                    <input type="text" name="salary_range" class="form-control"
                                        value="<?= htmlspecialchars($job['salary_range'] ?? '') ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Application Deadline</label>
                                    <input type="date" name="application_deadline" class="form-control"
                                        value="<?= htmlspecialchars($job['application_deadline'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Job Description *</label>
                                <textarea name="description" class="form-control" rows="5"
                                    required><?= htmlspecialchars($job['description']) ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Requirements & Qualifications</label>
                                <textarea name="requirements" class="form-control"
                                    rows="4"><?= htmlspecialchars($job['requirements'] ?? '') ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block mt-4">Save Changes</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
<?php
session_start();
include('config.php');

$msg = "";
$type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST['full_name']);
    $email     = trim($_POST['email']);
    $password  = $_POST['password'];
    $role      = isset($_POST['role']) && in_array($_POST['role'], ['student', 'instructor', 'expert']) ? $_POST['role'] : 'student';
    $phone     = trim($_POST['phone']);
    $bio       = trim($_POST['bio']);
    $education = trim($_POST['education']);
    $skills    = trim($_POST['skills']);
    $location  = trim($_POST['location']);
    $address   = trim($_POST['address']);

    if (strlen($password) < 8) {
        $msg = "Password must be at least 8 characters long.";
        $type = "danger";
    } else {
        $check_email_stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($check_email_stmt, "s", $email);
        mysqli_stmt_execute($check_email_stmt);
        mysqli_stmt_store_result($check_email_stmt);

        if (mysqli_stmt_num_rows($check_email_stmt) > 0) {
            $msg = "Email address is already registered.";
            $type = "danger";
            mysqli_stmt_close($check_email_stmt);
        } else {
            mysqli_stmt_close($check_email_stmt);

            $password_hash = password_hash($password, PASSWORD_DEFAULT);

            $sql_user = "INSERT INTO users (full_name, email, password, role, phone, bio, education, skills, location, address, status) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')";
            
            $stmt_user = mysqli_prepare($conn, $sql_user);
            mysqli_stmt_bind_param($stmt_user, "ssssssssss", $full_name, $email, $password_hash, $role, $phone, $bio, $education, $skills, $location, $address);

            if (mysqli_stmt_execute($stmt_user)) {
                $msg = "Registration successful! You can now log in.";
                $type = "success";
            } else {
                $msg = "Registration failed. Please try again.";
                $type = "danger";
            }
            mysqli_stmt_close($stmt_user);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>

<body class="bg-light">

    <?php if(file_exists('navbar.php')) include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Create Your AQDesk Account</h3>

                        <?php if ($msg): ?>
                        <div class="alert alert-<?= $type ?> text-center">
                            <?= htmlspecialchars($msg) ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="register.php">

                            <h5 class="text-secondary border-bottom pb-2 mb-3">Account & Profile Information</h5>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Full Name *</label>
                                    <input type="text" name="full_name" class="form-control" placeholder="e.g. John Doe"
                                        required
                                        value="<?= isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : '' ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Email Address *</label>
                                    <input type="email" name="email" class="form-control" placeholder="example@mail.com"
                                        required
                                        value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Password *</label>
                                    <input type="password" name="password" class="form-control" required minlength="8"
                                        placeholder="At least 8 characters">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Role *</label>
                                    <select name="role" class="form-control" required>
                                        <option value="student"
                                            <?= (isset($_POST['role']) && $_POST['role'] === 'student') ? 'selected' : '' ?>>
                                            Student</option>
                                        <option value="instructor"
                                            <?= (isset($_POST['role']) && $_POST['role'] === 'instructor') ? 'selected' : '' ?>>
                                            Instructor</option>
                                        <option value="expert"
                                            <?= (isset($_POST['role']) && $_POST['role'] === 'expert') ? 'selected' : '' ?>>
                                            Expert</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Phone</label>
                                    <input type="text" name="phone" class="form-control" placeholder="+1234567890"
                                        value="<?= isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : '' ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Location</label>
                                    <input type="text" name="location" class="form-control"
                                        placeholder="e.g. New York, USA"
                                        value="<?= isset($_POST['location']) ? htmlspecialchars($_POST['location']) : '' ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Education</label>
                                    <input type="text" name="education" class="form-control"
                                        placeholder="e.g. BS Computer Science"
                                        value="<?= isset($_POST['education']) ? htmlspecialchars($_POST['education']) : '' ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Skills</label>
                                    <input type="text" name="skills" class="form-control"
                                        placeholder="e.g. PHP, Laravel, MySQL"
                                        value="<?= isset($_POST['skills']) ? htmlspecialchars($_POST['skills']) : '' ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>Bio</label>
                                    <textarea name="bio" class="form-control" rows="2"
                                        placeholder="Brief intro..."><?= isset($_POST['bio']) ? htmlspecialchars($_POST['bio']) : '' ?></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 form-group">
                                    <label>Address</label>
                                    <textarea name="address" class="form-control" rows="2"
                                        placeholder="Complete address"><?= isset($_POST['address']) ? htmlspecialchars($_POST['address']) : '' ?></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block mt-4">Register Account</button>

                        </form>

                        <p class="text-center mt-3 mb-0">
                            Already registered? <a href="login.php">Login here</a>
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
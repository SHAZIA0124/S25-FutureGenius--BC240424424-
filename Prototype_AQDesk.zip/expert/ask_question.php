<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$msg = "";
$type = "";

$categories_result = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title       = trim($_POST['title']);
    $category_id = intval($_POST['category_id']);
    $content     = trim($_POST['content']);

    if (empty($title) || empty($content) || $category_id <= 0) {
        $msg = "Please fill in all required fields.";
        $type = "danger";
    } else {
        $sql = "INSERT INTO questions (user_id, category_id, title, content) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iiss", $user_id, $category_id, $title, $content);

        if (mysqli_stmt_execute($stmt)) {
            $question_id = mysqli_insert_id($conn);
            mysqli_stmt_close($stmt);
            header("Location: question_detail.php?id=" . $question_id);
            exit();
        } else {
            $msg = "Failed to post question. Please try again.";
            $type = "danger";
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ask Question - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php  include('navbar.php'); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <div class="card shadow-sm border-0" style="border-radius: 12px;">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Ask a Public Question</h3>

                        <?php if ($msg): ?>
                        <div class="alert alert-<?= $type ?> text-center">
                            <?= htmlspecialchars($msg) ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="ask_question.php">

                            <div class="form-group">
                                <label>Question Title *</label>
                                <input type="text" name="title" class="form-control"
                                    placeholder="e.g. How to handle CORS in PHP API?" required>
                            </div>

                            <div class="form-group">
                                <label>Category *</label>
                                <select name="category_id" class="form-control" required>
                                    <option value="">-- Select Category --</option>
                                    <?php while ($cat = mysqli_fetch_assoc($categories_result)): ?>
                                    <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Detailed Description *</label>
                                <textarea name="content" class="form-control" rows="6"
                                    placeholder="Provide details, code snippet, or specifics..." required></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block mt-4">Post Your Question</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
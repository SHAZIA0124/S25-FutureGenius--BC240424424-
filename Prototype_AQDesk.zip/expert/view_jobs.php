<?php
session_start();
include('config.php');

$user_id = $_SESSION["user_id"] ?? 0;
$user_role = strtolower($_SESSION["role"] ?? '');

$msg = "";
$type = "";

if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    if (!$user_id || !in_array($user_role, ['instructor', 'expert', 'admin'])) {
        header("Location: view_jobs.php");
        exit();
    }

    $delete_id = intval($_GET['id']);
    
    $check_sql = "SELECT posted_by FROM jobs WHERE id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $delete_id);
    mysqli_stmt_execute($check_stmt);
    $job_owner = mysqli_fetch_assoc(mysqli_stmt_get_result($check_stmt));
    mysqli_stmt_close($check_stmt);

    if ($job_owner && ($job_owner['posted_by'] == $user_id || $user_role === 'admin')) {
        $del_sql = "DELETE FROM jobs WHERE id = ?";
        $del_stmt = mysqli_prepare($conn, $del_sql);
        mysqli_stmt_bind_param($del_stmt, "i", $delete_id);
        
        if (mysqli_stmt_execute($del_stmt)) {
            $msg = "Job listing deleted successfully.";
            $type = "success";
        } else {
            $msg = "Failed to delete job listing.";
            $type = "danger";
        }
        mysqli_stmt_close($del_stmt);
    } else {
        $msg = "You are not authorized to delete this post.";
        $type = "danger";
    }
}

if (isset($_GET['msg']) && $_GET['msg'] === 'added') {
    $msg = "Job opportunity posted successfully!";
    $type = "success";
} elseif (isset($_GET['msg']) && $_GET['msg'] === 'updated') {
    $msg = "Job opportunity updated successfully!";
    $type = "success";
}

$sql = "SELECT j.*, u.full_name FROM jobs j JOIN users u ON j.posted_by = u.id WHERE j.is_active = 1 ORDER BY j.created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobs & Opportunities Board - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php include('navbar.php'); ?>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Jobs & Opportunities Board</h2>
            <?php if (in_array($user_role, ['instructor', 'expert'])): ?>
            <a href="add_job.php" class="btn btn-primary"><i class="fas fa-plus mr-1"></i> Post New Job</a>
            <?php endif; ?>
        </div>

        <?php if ($msg): ?>
        <div class="alert alert-<?= $type ?> text-center">
            <?= htmlspecialchars($msg) ?>
        </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="thead-dark">
                            <tr>
                                <th>Title & Company</th>
                                <th>Type</th>
                                <th>Location</th>
                                <th>Salary</th>
                                <th>Deadline</th>
                                <th>Posted By</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($job = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <strong class="text-primary d-block"><?= htmlspecialchars($job['title']) ?></strong>
                                    <small class="text-muted"><i
                                            class="fas fa-building mr-1"></i><?= htmlspecialchars($job['company_name'] ?? 'N/A') ?></small>
                                </td>
                                <td>
                                    <span
                                        class="badge badge-info text-uppercase p-2"><?= htmlspecialchars($job['job_type']) ?></span>
                                </td>
                                <td><?= htmlspecialchars($job['location'] ?? 'Not specified') ?></td>
                                <td><?= htmlspecialchars($job['salary_range'] ?? 'Negotiable') ?></td>
                                <td><?= $job['application_deadline'] ? date('d M Y', strtotime($job['application_deadline'])) : 'Open' ?>
                                </td>
                                <td><?= htmlspecialchars($job['full_name']) ?></td>
                                <td class="text-center">
                                    <?php if ($job['posted_by'] == $user_id || $user_role === 'admin'): ?>
                                    <a href="edit_job.php?id=<?= $job['id'] ?>"
                                        class="btn btn-sm btn-outline-secondary mr-1"><i class="fas fa-edit"></i>
                                        Edit</a>
                                    <a href="view_jobs.php?action=delete&id=<?= $job['id'] ?>"
                                        class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Are you sure you want to delete this opportunity?');"><i
                                            class="fas fa-trash"></i> Delete</a>
                                    <?php else: ?>
                                    <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center p-4 text-muted">No opportunities posted yet.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
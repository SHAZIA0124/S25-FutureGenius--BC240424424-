<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$job_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($job_id <= 0) {
    header("Location: student_jobs.php");
    exit();
}

$sql = "SELECT j.*, u.full_name, u.email AS recruiter_email 
        FROM jobs j 
        JOIN users u ON j.posted_by = u.id 
        WHERE j.id = ? AND j.is_active = 1";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $job_id);
mysqli_stmt_execute($stmt);
$job = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$job) {
    echo "<div class='container my-5 alert alert-danger text-center'>Job opportunity not found or inactive. <a href='student_jobs.php'>Back to listings</a></div>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($job['title']) ?> - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php include('navbar.php'); ?>

    <div class="container my-5">
        <a href="student_jobs.php" class="btn btn-outline-secondary mb-4"><i class="fas fa-arrow-left mr-1"></i> Back to
            Opportunities</a>

        <div class="card border-0 shadow-sm">
            <div class="card-body p-4 p-md-5">
                <div class="d-flex justify-content-between align-items-start border-bottom pb-4 mb-4">
                    <div>
                        <h2 class="font-weight-bold text-primary mb-2"><?= htmlspecialchars($job['title']) ?></h2>
                        <h5 class="text-muted mb-0"><i class="fas fa-building mr-1"></i>
                            <?= htmlspecialchars($job['company_name'] ?? 'N/A') ?></h5>
                    </div>
                    <span class="badge badge-info text-uppercase p-2"><?= htmlspecialchars($job['job_type']) ?></span>
                </div>

                <div class="row text-secondary mb-4">
                    <div class="col-md-3 mb-2"><i
                            class="fas fa-map-marker-alt text-danger mr-2"></i><strong>Location:</strong><br><?= htmlspecialchars($job['location'] ?? 'Not specified') ?>
                    </div>
                    <div class="col-md-3 mb-2"><i
                            class="fas fa-money-bill-wave text-success mr-2"></i><strong>Salary:</strong><br><?= htmlspecialchars($job['salary_range'] ?? 'Negotiable') ?>
                    </div>
                    <div class="col-md-3 mb-2"><i
                            class="fas fa-calendar-alt text-warning mr-2"></i><strong>Deadline:</strong><br><?= $job['application_deadline'] ? date('d M Y', strtotime($job['application_deadline'])) : 'Open' ?>
                    </div>
                    <div class="col-md-3 mb-2"><i class="fas fa-user-check text-info mr-2"></i><strong>Posted
                            By:</strong><br><?= htmlspecialchars($job['full_name']) ?></div>
                </div>

                <div class="mb-4">
                    <h5 class="font-weight-bold border-bottom pb-2">Description</h5>
                    <p class="text-dark" style="line-height: 1.8;"><?= nl2br(htmlspecialchars($job['description'])) ?>
                    </p>
                </div>

                <?php if (!empty($job['requirements'])): ?>
                <div class="mb-4">
                    <h5 class="font-weight-bold border-bottom pb-2">Requirements & Qualifications</h5>
                    <p class="text-dark" style="line-height: 1.8;"><?= nl2br(htmlspecialchars($job['requirements'])) ?>
                    </p>
                </div>
                <?php endif; ?>

                <div class="bg-light p-4 rounded border mt-5 d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="font-weight-bold mb-1">Interested in this role?</h6>
                        <small class="text-muted">Contact recruiter at
                            <?= htmlspecialchars($job['recruiter_email']) ?></small>
                    </div>
                    <a href="mailto:<?= htmlspecialchars($job['recruiter_email']) ?>?subject=Application for <?= urlencode($job['title']) ?>"
                        class="btn btn-success"><i class="fas fa-paper-plane mr-1"></i> Apply Now</a>
                </div>

            </div>
        </div>
    </div>

</body>

</html>
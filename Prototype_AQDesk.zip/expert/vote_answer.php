<?php
session_start();
include('config.php');

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id     = $_SESSION["user_id"];
$answer_id   = isset($_GET['answer_id']) ? intval($_GET['answer_id']) : 0;
$question_id = isset($_GET['question_id']) ? intval($_GET['question_id']) : 0;
$vote_type   = isset($_GET['vote']) && in_array($_GET['vote'], ['upvote', 'downvote']) ? $_GET['vote'] : '';

if ($answer_id > 0 && $question_id > 0 && !empty($vote_type)) {
    $sql = "INSERT INTO answer_votes (answer_id, user_id, vote_type) VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE vote_type = VALUES(vote_type)";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "iis", $answer_id, $user_id, $vote_type);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

header("Location: question_detail.php?id=" . $question_id);
exit();
?>
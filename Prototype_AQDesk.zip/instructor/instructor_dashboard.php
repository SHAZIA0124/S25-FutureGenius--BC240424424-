<?php
session_start();
include('../config.php');

if (!isset($_SESSION["user_id"]) || strtolower($_SESSION["role"]) !== "instructor") {
    header("Location: ../login.php");
    exit();
}

$user_id   = $_SESSION["user_id"];
$user_name = $_SESSION["full_name"] ?? "Instructor User";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructor Panel - AQDesk</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">

    <style>
    .welcome-box {
        background: linear-gradient(135deg, #28a745, #1e7e34);
        color: white;
        border-radius: 15px;
        padding: 40px 30px;
        text-align: center;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .simple-card {
        border: none;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
        transition: 0.2s;
    }

    .simple-card:hover {
        transform: translateY(-3px);
    }
    </style>
</head>

<body class="bg-light">

    <?php if(file_exists('navbar.php')) include('navbar.php'); ?>

    <div class="container mt-5 mb-5">

        <div class="welcome-box mb-5">
            <h2 class="font-weight-bold mb-2 text-white">Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
            <p class="mb-0 lead">You have successfully logged in to the AQDesk Instructor Panel.</p>
            <p class="mb-0">Guide students, moderate discussions, and share knowledge.</p>
        </div>

        <div class="row text-center">
            <div class="col-md-4 mb-4">
                <div class="card simple-card p-4">
                    <div class="mb-3">
                        <i class="fas fa-chalkboard-teacher fa-2x text-success"></i>
                    </div>
                    <h5 class="font-weight-bold">Academic Guidance</h5>
                    <p class="text-muted mb-0">Help & Review Discussions</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card simple-card p-4">
                    <div class="mb-3">
                        <i class="fas fa-user-tie fa-2x text-dark"></i>
                    </div>
                    <h5 class="font-weight-bold">Role</h5>
                    <p class="text-muted mb-0">Instructor</p>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card simple-card p-4">
                    <div class="mb-3">
                        <i class="fas fa-calendar-alt fa-2x text-warning"></i>
                    </div>
                    <h5 class="font-weight-bold">Login Time</h5>
                    <p class="text-muted mb-0"><?php echo date('d M Y, h:i A'); ?></p>
                </div>
            </div>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
<?php
session_start();
include('config.php');

$question_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$msg = "";
$type = "";

if ($question_id <= 0) {
    header("Location: questions.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_answer'])) {
    if (!isset($_SESSION["user_id"])) {
        header("Location: login.php");
        exit();
    }

    $answer_content = trim($_POST['content']);
    $user_id = $_SESSION["user_id"];

    if (!empty($answer_content)) {
        $ans_sql = "INSERT INTO answers (question_id, user_id, content) VALUES (?, ?, ?)";
        $ans_stmt = mysqli_prepare($conn, $ans_sql);
        mysqli_stmt_bind_param($ans_stmt, "iis", $question_id, $user_id, $answer_content);
        
        if (mysqli_stmt_execute($ans_stmt)) {
            $msg = "Your answer has been posted successfully.";
            $type = "success";
        } else {
            $msg = "Failed to post answer.";
            $type = "danger";
        }
        mysqli_stmt_close($ans_stmt);
    } else {
        $msg = "Answer content cannot be empty.";
        $type = "danger";
    }
}

$q_sql = "SELECT q.*, u.full_name, c.name AS category_name 
          FROM questions q 
          JOIN users u ON q.user_id = u.id 
          JOIN categories c ON q.category_id = c.id 
          WHERE q.id = ?";
$q_stmt = mysqli_prepare($conn, $q_sql);
mysqli_stmt_bind_param($q_stmt, "i", $question_id);
mysqli_stmt_execute($q_stmt);
$question = mysqli_fetch_assoc(mysqli_stmt_get_result($q_stmt));
mysqli_stmt_close($q_stmt);

if (!$question) {
    echo "Question not found.";
    exit();
}

$ans_list_sql = "SELECT a.*, u.full_name,
                (SELECT COUNT(*) FROM answer_votes v WHERE v.answer_id = a.id AND v.vote_type = 'upvote') AS upvotes,
                (SELECT COUNT(*) FROM answer_votes v WHERE v.answer_id = a.id AND v.vote_type = 'downvote') AS downvotes
                FROM answers a
                JOIN users u ON a.user_id = u.id
                WHERE a.question_id = ?
                ORDER BY a.is_accepted DESC, a.created_at ASC";
$ans_list_stmt = mysqli_prepare($conn, $ans_list_sql);
mysqli_stmt_bind_param($ans_list_stmt, "i", $question_id);
mysqli_stmt_execute($ans_list_stmt);
$answers_result = mysqli_stmt_get_result($ans_list_stmt);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($question['title']) ?> - AQDesk</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="bg-light">

    <?php  include('navbar.php'); ?>

    <div class="container my-5">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <span class="badge badge-info mb-2"><?= htmlspecialchars($question['category_name']) ?></span>
                <h3><?= htmlspecialchars($question['title']) ?></h3>
                <p class="text-muted border-bottom pb-2">
                    Asked by <strong><?= htmlspecialchars($question['full_name']) ?></strong> on
                    <?= date('d M Y, h:i A', strtotime($question['created_at'])) ?>
                </p>
                <div class="question-content my-3">
                    <?= nl2br(htmlspecialchars($question['content'])) ?>
                </div>
            </div>
        </div>

        <?php if ($msg): ?>
        <div class="alert alert-<?= $type ?> text-center">
            <?= htmlspecialchars($msg) ?>
        </div>
        <?php endif; ?>

        <h4 class="mb-3">Answers (<?= mysqli_num_rows($answers_result) ?>)</h4>

        <?php while ($ans = mysqli_fetch_assoc($answers_result)): ?>
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-1 text-center border-right">
                        <a href="vote_answer.php?answer_id=<?= $ans['id'] ?>&question_id=<?= $question_id ?>&vote=upvote"
                            class="text-secondary"><i class="fas fa-caret-up fa-2x"></i></a>
                        <div class="font-weight-bold my-1"><?= ($ans['upvotes'] - $ans['downvotes']) ?></div>
                        <a href="vote_answer.php?answer_id=<?= $ans['id'] ?>&question_id=<?= $question_id ?>&vote=downvote"
                            class="text-secondary"><i class="fas fa-caret-down fa-2x"></i></a>
                    </div>
                    <div class="col-md-11">
                        <p><?= nl2br(htmlspecialchars($ans['content'])) ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top">
                            <small class="text-muted">Answered by
                                <strong><?= htmlspecialchars($ans['full_name']) ?></strong> on
                                <?= date('d M Y, h:i A', strtotime($ans['created_at'])) ?></small>
                            <?php if($ans['is_accepted']): ?>
                            <span class="badge badge-success"><i class="fas fa-check"></i> Accepted Answer</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>

        <div class="card border-0 shadow-sm mt-4">
            <div class="card-body p-4">
                <h5 class="mb-3">Your Answer</h5>
                <?php if (isset($_SESSION["user_id"])): ?>
                <form method="POST" action="question_detail.php?id=<?= $question_id ?>">
                    <div class="form-group">
                        <textarea name="content" class="form-control" rows="4" placeholder="Write your answer here..."
                            required></textarea>
                    </div>
                    <button type="submit" name="submit_answer" class="btn btn-primary">Post Answer</button>
                </form>
                <?php else: ?>
                <p class="text-muted mb-0">Please <a href="login.php">login</a> to submit an answer.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>

</html>